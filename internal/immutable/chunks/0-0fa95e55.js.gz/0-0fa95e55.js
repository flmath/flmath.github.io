import{_ as r}from"./_layout-5bead24a.js";import{default as t}from"../components/pages/_layout.svelte-1716492c.js";export{t as component,r as shared};
