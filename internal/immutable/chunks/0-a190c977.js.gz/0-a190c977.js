import{_ as r}from"./_layout-409d426b.js";import{default as t}from"../components/pages/_layout.svelte-742b69a8.js";export{t as component,r as shared};
