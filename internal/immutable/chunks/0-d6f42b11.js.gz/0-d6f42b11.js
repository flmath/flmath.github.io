import{_ as r}from"./_layout-5bead24a.js";import{default as t}from"../components/pages/_layout.svelte-3dce565c.js";export{t as component,r as shared};
