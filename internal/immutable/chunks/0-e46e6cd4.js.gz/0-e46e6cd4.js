import{_ as r}from"./_layout-409d426b.js";import{default as t}from"../components/pages/_layout.svelte-8b16d0ba.js";export{t as component,r as shared};
