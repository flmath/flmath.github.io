import{default as t}from"../components/pages/_error.svelte-5c4a5283.js";export{t as component};
