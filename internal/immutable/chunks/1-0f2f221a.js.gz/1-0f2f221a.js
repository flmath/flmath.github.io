import{default as t}from"../components/pages/_error.svelte-77a1bcb4.js";export{t as component};
