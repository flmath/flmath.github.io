import{default as t}from"../components/pages/_error.svelte-8325709b.js";export{t as component};
