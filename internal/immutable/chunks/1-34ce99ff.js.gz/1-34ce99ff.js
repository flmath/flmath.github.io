import{default as t}from"../components/pages/_error.svelte-15f96ab1.js";export{t as component};
