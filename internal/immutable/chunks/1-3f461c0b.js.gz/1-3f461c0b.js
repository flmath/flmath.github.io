import{default as t}from"../components/pages/_error.svelte-23150b22.js";export{t as component};
