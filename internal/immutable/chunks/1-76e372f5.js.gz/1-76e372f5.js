import{default as t}from"../components/pages/_error.svelte-6e601075.js";export{t as component};
