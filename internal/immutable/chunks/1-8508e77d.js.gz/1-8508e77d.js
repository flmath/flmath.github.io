import{default as t}from"../components/pages/_error.svelte-543ad42c.js";export{t as component};
