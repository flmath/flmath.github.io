import{default as t}from"../components/pages/_error.svelte-2dc23d76.js";export{t as component};
