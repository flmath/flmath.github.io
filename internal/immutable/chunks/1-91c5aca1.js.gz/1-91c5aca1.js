import{default as t}from"../components/pages/_error.svelte-2835661d.js";export{t as component};
