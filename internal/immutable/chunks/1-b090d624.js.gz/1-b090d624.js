import{default as t}from"../components/pages/_error.svelte-abd7c248.js";export{t as component};
