import{default as t}from"../components/pages/_error.svelte-c16cccaa.js";export{t as component};
