import{default as t}from"../components/pages/_error.svelte-8b7a7e27.js";export{t as component};
