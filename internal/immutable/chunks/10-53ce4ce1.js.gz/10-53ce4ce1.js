import{_ as r}from"./_page-dd7e85cd.js";import{default as t}from"../components/pages/posts/jupyter/GrowthProjections/_page.svelte-76e3d35c.js";export{t as component,r as shared};
