import{default as t}from"../components/pages/posts/jupyter/GrowthProjections/_page.svelte-76e3d35c.js";export{t as component};
