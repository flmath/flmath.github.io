import{default as t}from"../components/pages/posts/jupyter/EmpiricalGrowthTesting/_page.svelte-aa26c78e.js";export{t as component};
