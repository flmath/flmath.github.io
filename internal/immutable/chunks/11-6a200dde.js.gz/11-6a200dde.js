import{default as t}from"../components/pages/posts/jupyter/Interpolation/_page.svelte-00dfe2ae.js";export{t as component};
