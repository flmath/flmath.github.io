import{_ as r}from"./_page-f58eb162.js";import{default as t}from"../components/pages/posts/jupyter/MatricesInErlang/_page.svelte-cd542e14.js";export{t as component,r as shared};
