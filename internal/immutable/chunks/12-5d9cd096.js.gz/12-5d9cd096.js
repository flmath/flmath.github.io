import{default as t}from"../components/pages/posts/jupyter/GrowthProjections/_page.svelte-3746ef72.js";export{t as component};
