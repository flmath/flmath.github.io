import{_ as r}from"./_page-d01fcb36.js";import{default as t}from"../components/pages/posts/jupyter/Interpolation/_page.svelte-00dfe2ae.js";export{t as component,r as shared};
