import{default as t}from"../components/pages/posts/jupyter/growth_projections/_page.svelte-aad761f9.js";export{t as component};
