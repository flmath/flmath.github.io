import{default as t}from"../components/pages/posts/jupyter/growth_projections/_page.svelte-956d18b4.js";export{t as component};
