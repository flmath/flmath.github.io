import{default as t}from"../components/pages/posts/jupyter/interpolation/_page.svelte-e2aa6bf8.js";export{t as component};
