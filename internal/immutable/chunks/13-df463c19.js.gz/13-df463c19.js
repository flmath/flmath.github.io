import{default as t}from"../components/pages/posts/jupyter/interpolation/_page.svelte-040a4c69.js";export{t as component};
