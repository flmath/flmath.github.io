import{default as t}from"../components/pages/posts/jupyter/MatricesInErlang/_page.svelte-48642801.js";export{t as component};
