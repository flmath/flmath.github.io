import{default as t}from"../components/pages/posts/jupyter/matrix_implementations_pt1/_page.svelte-275c864c.js";export{t as component};
