import{_ as r}from"./_layout-386ee8cc.js";import{default as t}from"../components/pages/exit_page/_layout.svelte-8261eddd.js";export{t as component,r as shared};
