import{default as t}from"../components/pages/_page.svelte-0a3745bb.js";export{t as component};
