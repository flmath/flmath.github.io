import{_ as r}from"./_layout-a2088a32.js";import{default as t}from"../components/pages/posts/ErlangDBG/_layout.svelte-ad34d8ba.js";export{t as component,r as shared};
