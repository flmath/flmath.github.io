import{default as t}from"../components/pages/_page.svelte-60b8eb0f.js";export{t as component};
