import{_ as r}from"./_page-1462131d.js";import{default as t}from"../components/pages/curriculum_vitae/_page.svelte-3f00e49e.js";export{t as component,r as shared};
