import{_ as r}from"./_page-473bc0e5.js";import{default as t}from"../components/pages/exit_page/_page.svelte-306393f7.js";export{t as component,r as shared};
