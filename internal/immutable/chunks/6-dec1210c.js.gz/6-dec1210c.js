import{_ as r}from"./_page-89f219c0.js";import{default as t}from"../components/pages/posts/_page.svelte-6d6c4af2.js";export{t as component,r as shared};
