import{default as t}from"../components/pages/posts/ErlangDBG/_page.svelte-a4ee9bbd.js";export{t as component};
