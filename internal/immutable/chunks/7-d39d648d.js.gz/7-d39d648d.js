import{_ as r}from"./_page-62600430.js";import{default as t}from"../components/pages/posts/ErlangDBG/_page.svelte-a4ee9bbd.js";export{t as component,r as shared};
