import{default as t}from"../components/pages/posts/ErlangDBG/_page.svelte-95c3120e.js";export{t as component};
