import{_ as r}from"./_page-2e34c424.js";import{default as t}from"../components/pages/posts/ErlangDBG/_page.svelte-a4ee9bbd.js";export{t as component,r as shared};
