import{_ as r}from"./_page-89518f60.js";import{default as t}from"../components/pages/posts/jupyter/_page.svelte-d1a1e86b.js";export{t as component,r as shared};
