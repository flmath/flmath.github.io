import{_ as r}from"./_page-a01b6da5.js";import{default as t}from"../components/pages/posts/jupyter/_page.svelte-d1a1e86b.js";export{t as component,r as shared};
