import{default as t}from"../components/pages/posts/jupyter/EmpiricalGrowthTesting/_page.svelte-7a1d99c7.js";export{t as component};
