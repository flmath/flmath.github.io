import{default as t}from"../components/pages/posts/jupyter/Empirical_growth_testing/_page.svelte-4aaf46cf.js";export{t as component};
