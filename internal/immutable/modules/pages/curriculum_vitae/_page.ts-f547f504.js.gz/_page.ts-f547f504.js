import{c as e,p as a,s as p}from"../../../chunks/_page-1462131d.js";export{e as csr,a as prerender,p as ssr};
