import{c as e,p as a,s as p}from"../../../chunks/_page-473bc0e5.js";export{e as csr,a as prerender,p as ssr};
